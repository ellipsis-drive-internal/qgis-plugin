QGIS plugin for Ellipsis Drive.
